import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_log_error
from sklearn.impute import SimpleImputer

# Load data
df = pd.read_csv('data.csv')

# Basic preprocessing: select a few numeric features and fill missing values
features = ['budget', 'popularity', 'runtime']
X = df[features]
y = df['revenue']

# Handle missing values
imputer = SimpleImputer(strategy='mean')
X = imputer.fit_transform(X)

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
rmsle = np.sqrt(mean_squared_log_error(y_test, np.maximum(0, y_pred)))
print(f'RMSLE: {rmsle:.4f}')
