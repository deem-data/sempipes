import pandas as pd
import numpy as np

# Load files
labels = pd.read_csv('labels_predictions.csv')
attr = pd.read_csv('attr.csv')

# Map image names: extract number, zero-pad to 6 digits
labels['image_id'] = labels['image'].apply(lambda x: f"{int(x.split('/')[-1].split('.')[0]):06d}.jpg")

# Attributes of interest
attributes = {
    'gender': 'Male',
    'makeup': 'Heavy_Makeup',
    'skin_color': 'Pale_Skin',
    'hair_color': ['Black_Hair', 'Blond_Hair', 'Brown_Hair', 'Gray_Hair'],
    'beard': 'No_Beard',
    'young': 'Young'
}

# Merge on image_id
merged = pd.merge(labels, attr, left_on='image_id', right_on='image_id', how='inner')

# TODO: Replace this function with real attribute extraction from images.
# Simulate attribute extraction: random assignment
def extract_attributes_random(row):
    result = {}
    rng = np.random.default_rng()
    for k, v in attributes.items():
        if isinstance(v, list):
            # Randomly pick one hair color or 'None'
            options = v + ['None']
            result[k] = rng.choice(options)
        else:
            result[k] = rng.choice([-1, 1])
    return pd.Series(result)

def extract_attributes_gt(row):
    result = {}
    for k, v in attributes.items():
        if isinstance(v, list):
            found = None
            for color in v:
                if row[color] == 1:
                    found = color
                    break
            result[k] = found if found else 'None'
        else:
            result[k] = row[v]
    return pd.Series(result)

# Apply simulated extraction
extracted = merged.apply(extract_attributes_random, axis=1)
ground_truth = merged.apply(extract_attributes_gt, axis=1)

# For categorical (hair_color), compare equality; for binary, compare values
accuracies = []
for col in attributes.keys():
    if col == 'hair_color':
        acc = np.mean(extracted[col] == ground_truth[col])
    else:
        acc = np.mean(extracted[col].values == ground_truth[col].values)
    accuracies.append(acc)

mean_accuracy = np.mean(accuracies)
print(f"Mean attribute accuracy: {mean_accuracy:.4f}")
