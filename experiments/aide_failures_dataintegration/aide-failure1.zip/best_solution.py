import pandas as pd
import numpy as np
from xgboost import XGBRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_log_error

# Load the dataset
data = pd.read_csv("./input/train.csv")
test_data = pd.read_csv("./input/test.csv")

# Assuming 'gdp' is the target variable and the first column is an identifier
X = data.drop(["gdp"], axis=1)
y = data["gdp"]
X_test = test_data.drop(["id"], axis=1)

# Split the data into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train the XGBoost regressor
model = XGBRegressor(
    objective="reg:squaredlogerror", n_estimators=100, learning_rate=0.1, max_depth=5
)
model.fit(X_train, y_train)

# Predict on validation set
y_pred_val = model.predict(X_val)
y_pred_val = np.maximum(0, y_pred_val)  # Ensure predictions are non-negative

# Calculate RMSLE
rmsle = np.sqrt(mean_squared_log_error(y_val, y_pred_val))
print(f"Validation RMSLE: {rmsle}")

# Predict on test set
y_test_pred = model.predict(X_test)
y_test_pred = np.maximum(0, y_test_pred)  # Ensure predictions are non-negative

# Save predictions to a CSV file for submission
submission = pd.DataFrame({"id": test_data["id"], "gdp": y_test_pred})
submission.to_csv("./working/submission.csv", index=False)
