import pandas as pd
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

# Load data
data = pd.read_csv("./input/repayments.csv")

# Define features and target
X = data.drop(["id", "repaid"], axis=1)
y = data["repaid"]

# Preprocessing for numerical data
numeric_features = [
    "age",
    "credit_score",
    "dti",
    "employment_years",
    "income",
    "loan_amount",
]
numeric_transformer = StandardScaler()

# Preprocessing for categorical data
categorical_features = ["education", "gender", "zipcode"]
categorical_transformer = OneHotEncoder(handle_unknown="ignore")

# Bundle preprocessing for numerical and categorical data
preprocessor = ColumnTransformer(
    transformers=[
        ("num", numeric_transformer, numeric_features),
        ("cat", categorical_transformer, categorical_features),
    ]
)

# Create a pipeline that processes the data and then runs the classifier
pipeline = Pipeline(
    steps=[("preprocessor", preprocessor), ("classifier", SVC(kernel="linear"))]
)

# Define parameter grid
param_grid = {"classifier__C": [0.1, 1, 10, 100]}

# Create GridSearchCV object
grid_search = GridSearchCV(pipeline, param_grid, cv=5, scoring="accuracy")

# Split data into train and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model using grid search
grid_search.fit(X_train, y_train)

# Best model
best_model = grid_search.best_estimator_

# Predict and evaluate the model
y_pred = best_model.predict(X_val)
accuracy = accuracy_score(y_val, y_pred)
print(f"Validation Accuracy: {accuracy}")
