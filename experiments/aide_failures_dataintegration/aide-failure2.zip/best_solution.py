import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_log_error
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer

# Load data
data = pd.read_csv("./input/countries_gdp_data.csv")

# Features and target
features = ["population", "unemployment_rate", "inflation_rate", "trade_balance"]
target = "gdp"

# Prepare data
X = data[features]
y = data[target]

# Handling missing values
imputer = SimpleImputer(strategy="mean")
X_imputed = imputer.fit_transform(X)

# Feature scaling
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_imputed)

# Splitting the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X_scaled, y, test_size=0.2, random_state=42
)

# Model initialization and training
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Calculate RMSLE
rmsle = np.sqrt(mean_squared_log_error(y_test, y_pred))
print(f"Root Mean Squared Log Error: {rmsle}")

# Save predictions for evaluation
test_predictions = model.predict(scaler.transform(imputer.transform(data[features])))
submission = pd.DataFrame(
    {"Country": data["country"], "Predicted_GDP": test_predictions}
)
submission.to_csv("./working/submission.csv", index=False)
