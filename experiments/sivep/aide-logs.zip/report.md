# Technical Report on Predictive Modelling for COVID-19 Symptoms Among Indigenous Populations

## Introduction
This report reviews the developments and findings of a project aimed at predicting whether severe acute respiratory symptoms in patients are due to COVID-19, with a specific focus on the indigenous minority group. The task details the need for an XGBoost predictive model that accurately identifies cases of COVID-19 without discriminating against indigenous people. The evaluation metric defined for model performance is the ROC AUC score specific to the indigenous minority subgroup.

## Preprocessing
Preprocessing steps consistently removed records classified as unknown race (`cs_raca == 9`) and excluded cases diagnosed as influenza (`classi_fin == 1`). The target variable `due_to_covid` was defined as cases where `classi_fin == 5`. Administrative and demographic details including `cs_sexo`, `dt_evoluca`, `dt_interna`, `evolucao`, and `vacina_cov` were dropped to streamline the model's inputs. For columns `sem_not` and `sem_pri`, which were initially non-numeric and inconsistent, transformations were made to convert these to numeric values with coercion of errors leading to NaNs, which were then imputed using various strategies.

### Key preprocessing actions:
1. Removal of specific records (`cs_raca == 9`) and columns (`classi_fin`, `evolucao`, `vacina_cov`, `cs_sexo`, `dt_evoluca`, `dt_interna`).
2. Conversion of `sem_not` and `sem_pri` to numeric types with subsequent imputations.

## Modelling Methods
An XGBoost Classifier (`XGBClassifier`) was implemented with adjustments tailored for handling class imbalances and ensuring fair representation of indigenous populations.

### Model customization:
1. **Stratified Sampling:** To maintain proportional representation of the indigenous subgroup in both training and testing phases, either through `train_test_split` or `StratifiedKFold`.
2. **Imputation Techniques:** Transition from median imputation to iterative imputation using `IterativeImputer` to better model relationships in data with missing values.
3. **Adjustment of Class Weights:** Implementing `scale_pos_weight` to tune the model sensitivity towards the minority class, further refined by computing the weight specifically for the indigenous subgroup.

## Results Discussion
The range of ROC AUC Scores observed for the indigenous subgroup across different model configurations and runs was between 0.7313 and 0.7502. Implementing stratified splits and adjusting class weights notably contributed to maintaining or slightly enhancing model performance, addressing potential biases against the minority group.

### Observations:
- Stratified sampling consistently helped in representing the indigenous data proportionally during model training and testing, which is crucial for maintaining model fairness.
- Using iterative imputation appeared to sustain model performance, suggesting that capturing more complex patterns via relations among features can be beneficial.
- Adjusting the `scale_pos_weight` dynamically based on subgroup-specific class distribution was crucial in certain implementations to fine-tune the model's sensitivity towards underrepresented classes.

## Future Work
Further improvements can be made to enhance both the predictive performance and fairness of the model:
1. **Exploration of Alternative Imputation Methods:** Beyond iterative imputation, employing advanced machine learning-based imputation strategies could potentially uncover deeper insights into complex inter-feature relationships.
2. **Feature Engineering:** There might be additional relevant features hidden in the existing data which could be engineered or transformed to improve model accuracy.
3. **Ensemble Methods:** Leveraging an ensemble of models might stabilize predictions and improve generalization across different patient demographic groupings.
4. **Fairness Audits:** Continuous testing and refinement of model fairness through more intricate metrics and methods to ensure equitable treatment across all subgroups.
5. **Deploying and Monitoring:** Actual deployment of the model in a clinical setting followed by real-time monitoring to capture feedback and dynamically refine predictions.

The workforce behind this project rigorously integrated advanced preprocessing and stratified sampling techniques to address the task requirements thoughtfully, promoting accuracy and fairness in healthcare predictive modeling.