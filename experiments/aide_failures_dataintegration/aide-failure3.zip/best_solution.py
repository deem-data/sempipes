import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_log_error
import lightgbm as lgb

# Load the data
train_data = pd.read_csv("./input/train.csv")
test_data = pd.read_csv("./input/test.csv")

# Basic preprocessing
train_data.fillna(train_data.mean(), inplace=True)
test_data.fillna(test_data.mean(), inplace=True)

# Encoding categorical variables if any
for col in train_data.select_dtypes(include=["object"]).columns:
    train_data[col], _ = pd.factorize(train_data[col])
    test_data[col], _ = pd.factorize(test_data[col])

# Split data into features and target
X = train_data.drop(["gdp"], axis=1)
y = np.log1p(train_data["gdp"])  # Use log1p to avoid issues with log(0)

# Splitting the dataset into training and validation sets
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42)

# Model training
model = lgb.LGBMRegressor()
model.fit(X_train, y_train)

# Predict on validation set
y_pred = model.predict(X_val)
y_pred = np.expm1(y_pred)  # Convert back from log scale
y_val = np.expm1(y_val)

# Calculate RMSLE
rmsle = np.sqrt(mean_squared_log_error(y_val, y_pred))
print(f"RMSLE on Validation Set: {rmsle}")

# Predict on test set
test_pred = model.predict(test_data.drop(["id"], axis=1))
test_pred = np.expm1(test_pred)

# Save predictions to submission.csv
submission = pd.DataFrame({"id": test_data["id"], "gdp": test_pred})
submission.to_csv("./working/submission.csv", index=False)
