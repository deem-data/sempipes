import pandas as pd
import numpy as np
from torchvision import models, transforms
from PIL import Image
from sklearn.metrics import accuracy_score

# Load data
attr_df = pd.read_csv("./input/attr.csv")
labels_predictions_df = pd.read_csv("./input/labels_predictions.csv")

# Define the attributes to predict
attributes = [
    "Male",
    "Heavy_Makeup",
    "Pale_Skin",
    "Black_Hair",
    "Blond_Hair",
    "Brown_Hair",
    "No_Beard",
    "Young",
]

# Preprocess function
preprocess = transforms.Compose(
    [
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ]
)

# Load the model (assuming a hypothetical pre-trained model exists)
# model = models.resnet50(pretrained=True)
# model.eval()  # Set the model to evaluation mode


# For the purpose of this example, we'll simulate predictions
def predict(image_path):
    # img = Image.open(image_path)
    # img_t = preprocess(img)
    # batch_t = torch.unsqueeze(img_t, 0)
    # out = model(batch_t)
    # Simulating prediction as random for demonstration
    return {attr: np.random.choice([-1, 1]) for attr in attributes}


# Predicting attributes
predictions = []
for _, row in labels_predictions_df.iterrows():
    image_path = "./input/" + row["image"]
    pred_attributes = predict(image_path)
    pred_attributes["image_id"] = row["image"].split("/")[-1]
    predictions.append(pred_attributes)

predictions_df = pd.DataFrame(predictions)

# Merge with ground truth
merged_df = pd.merge(
    predictions_df, attr_df, on="image_id", suffixes=("_pred", "_true")
)

# Calculate accuracy for each attribute
accuracies = {}
for attr in attributes:
    accuracies[attr] = accuracy_score(
        merged_df[attr + "_true"], merged_df[attr + "_pred"]
    )

# Mean accuracy across all attributes
mean_accuracy = np.mean(list(accuracies.values()))
print("Mean Accuracy:", mean_accuracy)
