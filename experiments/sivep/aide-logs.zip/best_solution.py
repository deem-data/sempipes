import pandas as pd
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.impute import SimpleImputer

# Load data
df = pd.read_csv("./input/data.csv")

# Preprocessing as per the skeleton provided
df = df[df.cs_raca != 9]  # Remove records with unreported race
df = df[~df.classi_fin.isin([1])]  # Remove influenza cases
df["due_to_covid"] = df.classi_fin == 5
df = df.drop(
    columns=[
        "classi_fin",
        "evolucao",
        "vacina_cov",
        "cs_sexo",
        "dt_evoluca",
        "dt_interna",
    ]
)

# Convert object columns to numeric and handle non-numeric issues
df["sem_not"] = pd.to_numeric(df["sem_not"], errors="coerce")
df["sem_pri"] = pd.to_numeric(df["sem_pri"], errors="coerce")

# Impute missing values in these columns
imputer = SimpleImputer(strategy="median")
df[["sem_not", "sem_pri"]] = imputer.fit_transform(df[["sem_not", "sem_pri"]])

# Splitting data into features and target
X = df.drop(columns=["due_to_covid"])
y = df["due_to_covid"]

# Calculate scale_pos_weight for imbalance handling specifically for indigenous group
indigenous_mask = df.cs_raca == 5
scale_pos_weight_indigenous = len(y[indigenous_mask & (y == 0)]) / len(
    y[indigenous_mask & (y == 1)]
)

# Split data into train and test sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train the model with scale_pos_weight consideration
model = XGBClassifier(
    eval_metric="logloss", random_state=42, scale_pos_weight=scale_pos_weight_indigenous
)
model.fit(X_train, y_train)

# Prediction and evaluation specifically for indigenous minority
X_test_indigenous = X_test[X_test.cs_raca == 5]
y_test_indigenous = y_test[X_test.cs_raca == 5]

y_pred_proba_indigenous = model.predict_proba(X_test_indigenous)[:, 1]
roc_auc = roc_auc_score(y_test_indigenous, y_pred_proba_indigenous)
print("ROC AUC Score for Indigenous Minority:", roc_auc)
