import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import sys

# Load data
df = pd.read_csv('data.csv')

# List of known bots
bots = ['HastyBot', 'BetterBot', 'STEEBot']

# Filter out bot players
df_humans = df[~df['nickname'].isin(bots)].copy()

if df_humans.empty:
    print("No human players found in the dataset. Exiting.")
    sys.exit(1)

# Features and target
X = df_humans[['score']]  # Only 'score' is available as a feature
y = df_humans['rating']

# Split into train and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train a regression model
model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# Predict and evaluate
y_pred = model.predict(X_test)
rmse = np.sqrt(mean_squared_error(y_test, y_pred))
print(f'RMSE: {rmse:.2f}')
